import React from 'react';

export default function CompatibilidadePage() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Compatibilidade</h1>
      <p>
        Um agricultor de frutas cadastra que terá <strong>500 kg de banana</strong> a partir de setembro.
        A Escola Municipal X informa que precisa de <strong>30 kg de banana por semana</strong>.
      </p>
      <div style={{ display: 'flex', gap: '2rem', marginTop: '2rem' }}>
        <div style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px', width: '100%' }}>
          <h3>Oferta</h3>
          <p><strong>José da Silva</strong><br />Agricultor Familiar</p>
          <p>🍌 Banana - 500 kg</p>
        </div>
        <div style={{ alignSelf: 'center', fontWeight: 'bold', color: 'green' }}>
          ✔️ Compatível
        </div>
        <div style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px', width: '100%' }}>
          <h3>Demanda</h3>
          <p><strong>Escola Municipal X</strong></p>
          <p>30 kg por semana</p>
        </div>
      </div>
    </div>
  );
}
