import React from 'react';
import ReactDOM from 'react-dom/client';
import CompatibilidadePage from './pages/CompatibilidadePage';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CompatibilidadePage />
  </React.StrictMode>
);